<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<?php
date_default_timezone_set("Asia/Jakarta"); //menyesuaikan dengan waktu di jakarta
$skrg=date("Y-m-d H:i:s"); //untuk menampilkan format waktu dalam contoh berikut 2015-10-1017:05:04
$jam_skrg=date("H:i:s"); //format jam
$tgl_skrg=date("Y-m-d"); //format tanggal
$hari_skrg=date("l"); //format hari (L kecil)
?>
</body>
</html>