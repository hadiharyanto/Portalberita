<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Layanan Iklan</title>
</head>

<body>
	<h1>CaraPasang Iklan</h1><hr>
	<h3>Kirimkan iklan yang ingin anda pasangn ke <a href="mailto:ad@yoginewportal.com">ad@yoginewportal.com</a></h3>
</body>
</html>